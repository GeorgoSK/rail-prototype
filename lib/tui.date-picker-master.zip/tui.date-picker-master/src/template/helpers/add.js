/**
 * @fileoverview Handlebars helper - add
 * @author NHN Ent. FE Development Lab <dl_javascript@nhnent.com>
 */

'use strict';

module.exports = function(a, b) {
    return a + b;
};
